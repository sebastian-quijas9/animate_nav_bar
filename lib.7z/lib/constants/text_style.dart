import 'package:flutter/cupertino.dart';
import 'color.dart';

const TextStyle bntText = TextStyle(
  color: black,
  fontWeight: FontWeight.w500,
);
